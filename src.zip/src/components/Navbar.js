import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import NoteContext from "../context/notes/NoteContext";

const Navbar = () => {
  const navigate = useNavigate();
  const context = useContext(NoteContext);
  const { setNotes } = context;
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setNotes([]);
    navigate("/login");
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav className="navbar">
      <div className="container">
        <div className="navbar-inner">
          <Link className="brand" to="/" onClick={closeMenu}>
            <span className="brand-icon">
              <i className="fa-solid fa-cloud" aria-hidden="true"></i>
            </span>
            <span>
              Cloud<span className="brand-accent">Note</span>
            </span>
          </Link>
          <button
            className="nav-toggle"
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
          >
            <i className={`fa-solid ${menuOpen ? "fa-xmark" : "fa-bars"}`} aria-hidden="true"></i>
          </button>
        </div>

        <div className={`navbar-menu ${menuOpen ? "open" : ""}`}>
          <ul className="nav-links">
            <li>
              <Link className="nav-link" to="/" onClick={closeMenu}>
                <i className="fa-solid fa-house" aria-hidden="true"></i> Home
              </Link>
            </li>
            <li>
              <Link className="nav-link" to="/about" onClick={closeMenu}>
                <i className="fa-solid fa-circle-info" aria-hidden="true"></i> About
              </Link>
            </li>
          </ul>

          {localStorage.getItem("token") ? (
            <div className="nav-actions">
              <button
                type="button"
                className="btn btn-danger-ghost"
                onClick={() => {
                  handleLogout();
                  closeMenu();
                }}
              >
                <i className="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>
                Logout
              </button>
            </div>
          ) : (
            <div className="nav-actions">
              <Link className="btn btn-ghost" to="/login" onClick={closeMenu}>
                Login
              </Link>
              <Link className="btn btn-primary" to="/signup" onClick={closeMenu}>
                Signup
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
