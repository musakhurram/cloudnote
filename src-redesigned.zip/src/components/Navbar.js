import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import NoteContext from "../context/notes/NoteContext";
import ThemeContext from "../context/theme/ThemeContext";

// Custom sun / moon marks for the theme toggle — drawn rather than pulled
// from the icon font so each can carry its own tone (warm amber for day,
// cool slate for night) instead of inheriting a single icon color.
const SunMark = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="5" fill="#FFFDF7" />
    <g stroke="#FFFDF7" strokeWidth="2" strokeLinecap="round">
      <line x1="12" y1="1.5" x2="12" y2="4" />
      <line x1="12" y1="20" x2="12" y2="22.5" />
      <line x1="1.5" y1="12" x2="4" y2="12" />
      <line x1="20" y1="12" x2="22.5" y2="12" />
      <line x1="4.4" y1="4.4" x2="6.1" y2="6.1" />
      <line x1="17.9" y1="17.9" x2="19.6" y2="19.6" />
      <line x1="4.4" y1="19.6" x2="6.1" y2="17.9" />
      <line x1="17.9" y1="6.1" x2="19.6" y2="4.4" />
    </g>
  </svg>
);

const MoonMark = () => (
  <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M20.5 14.2c-1.1.5-2.3.8-3.6.8-4.7 0-8.5-3.8-8.5-8.5 0-1.3.3-2.5.8-3.6C5.4 3.9 2.5 7.6 2.5 12c0 5.2 4.3 9.5 9.5 9.5 4.4 0 8.1-2.9 9.2-6.9.1-.2 0-.4-.2-.5-.2-.1-.4 0-.5.1z"
      fill="#F3F0E4"
    />
  </svg>
);

const Navbar = () => {
  const navigate = useNavigate();
  const context = useContext(NoteContext);
  const { setNotes } = context;
  const { theme, setThemePreference } = useContext(ThemeContext);
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setNotes([]);
    navigate("/login");
  };

  const closeMenu = () => setMenuOpen(false);

  const isDark = theme === "dark";
  const toggleTheme = () => setThemePreference(isDark ? "light" : "dark");

  return (
    <nav className="navbar">
      <div className="container">
        <div className="navbar-inner">
          <Link className="brand" to="/" onClick={closeMenu}>
            <span className="brand-icon">
              <i className="fa-solid fa-cloud" aria-hidden="true"></i>
            </span>
            <span>
              Cloud<span className="brand-accent">Note</span>
            </span>
          </Link>
          <button
            className="nav-toggle"
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
          >
            <i className={`fa-solid ${menuOpen ? "fa-xmark" : "fa-bars"}`} aria-hidden="true"></i>
          </button>
        </div>

        <div className={`navbar-menu ${menuOpen ? "open" : ""}`}>
          <div className="nav-actions">
            <Link className="nav-link" to="/about" onClick={closeMenu}>
              <i className="fa-solid fa-circle-info" aria-hidden="true"></i> About
            </Link>

            <button
              type="button"
              className={`theme-toggle ${isDark ? "is-dark" : ""}`}
              onClick={toggleTheme}
              role="switch"
              aria-checked={isDark}
              aria-label={`Switch to ${isDark ? "light" : "dark"} mode`}
              title={`Switch to ${isDark ? "light" : "dark"} mode`}
            >
              <span className="theme-toggle-thumb">
                {isDark ? <MoonMark /> : <SunMark />}
              </span>
            </button>

            {localStorage.getItem("token") ? (
              <button
                type="button"
                className="btn btn-danger-ghost"
                onClick={() => {
                  handleLogout();
                  closeMenu();
                }}
              >
                <i className="fa-solid fa-arrow-right-from-bracket" aria-hidden="true"></i>
                Logout
              </button>
            ) : (
              <>
                <Link className="btn btn-ghost" to="/login" onClick={closeMenu}>
                  Login
                </Link>
                <Link className="btn btn-primary" to="/signup" onClick={closeMenu}>
                  Signup
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
