import React, { useContext, useEffect, useRef, useState } from "react";
import Noteitem from "./Noteitem";
import Addnote from "./Addnote";
import NoteContext from "../context/notes/NoteContext";
import { useNavigate } from "react-router-dom";

const Notes = () => {
  const context = useContext(NoteContext);
  const { notes, getnotes, editnote } = context;
  const [note, setNote] = useState({
    id: "",
    title: "",
    description: "",
    tag: "",
  });
  const [modalOpen, setModalOpen] = useState(false);
  const titleRef = useRef(null);
  const navigate = useNavigate();

  const updatenote = (currentNote) => {
    setNote({
      id: currentNote._id,
      title: currentNote.title,
      description: currentNote.description,
      tag: currentNote.tag,
    });
    setModalOpen(true);
  };

  const closeModal = () => setModalOpen(false);

  const handleClick = async (e) => {
    e.preventDefault();
    if (note.title.trim().length < 3 || note.description.trim().length < 5) {
      console.error("Title must be at least 3 chars and description at least 5 chars.");
      return;
    }
    const success = await editnote(note.id, note.title, note.description, note.tag);
    if (success) {
      closeModal();
    }
  };

  const onChange = (e) => {
    setNote({ ...note, [e.target.name]: e.target.value });
  };

  // Focus the title input once the modal opens
  useEffect(() => {
    if (modalOpen && titleRef.current) {
      titleRef.current.focus();
    }
  }, [modalOpen]);

  // Close modal on Escape key
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") closeModal();
    };
    if (modalOpen) {
      document.addEventListener("keydown", handleKeyDown);
      return () => document.removeEventListener("keydown", handleKeyDown);
    }
  }, [modalOpen]);

  // Fetch notes on mount (include getnotes in deps for lint safety)
  useEffect(() => {
    if (localStorage.getItem("token")) {
      getnotes();
    } else {
      navigate("/login");
    }
  }, [getnotes, navigate]);

  const canSave =
    note.title.trim().length >= 3 && note.description.trim().length >= 5;

  return (
    <div className="page">
      <Addnote />

      <div className="page-header">
        <div>
          <h1 className="page-title">Your Notes</h1>
          <p className="page-subtitle">
            Everything you've saved, secured in the cloud.
          </p>
        </div>
        <span className="notes-count">
          <i className="fa-solid fa-layer-group" aria-hidden="true"></i>{" "}
          {notes.length} {notes.length === 1 ? "note" : "notes"}
        </span>
      </div>

      {notes.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">
            <i className="fa-solid fa-note-sticky" aria-hidden="true"></i>
          </div>
          <h2 className="empty-title">No notes yet</h2>
          <p className="empty-text">
            Create your first note above and it will appear here.
          </p>
        </div>
      ) : (
        <div className="notes-grid">
          {notes.map((item) => (
            <Noteitem key={item._id} updatenote={updatenote} note={item} />
          ))}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeModal();
          }}
        >
          <div className="modal" role="dialog" aria-modal="true" aria-labelledby="editModalTitle">
            <div className="modal-header">
              <h2 className="modal-title" id="editModalTitle">
                <i className="fa-solid fa-pen" aria-hidden="true"></i>
                Edit Note
              </h2>
              <button
                type="button"
                className="modal-close"
                onClick={closeModal}
                aria-label="Close"
              >
                <i className="fa-solid fa-xmark" aria-hidden="true"></i>
              </button>
            </div>
            <form onSubmit={handleClick}>
              <div className="modal-body">
                <div className="form-group">
                  <label htmlFor="edit-title" className="form-label">
                    Title
                  </label>
                  <input
                    ref={titleRef}
                    type="text"
                    className="form-control"
                    id="edit-title"
                    name="title"
                    value={note.title}
                    onChange={onChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="edit-description" className="form-label">
                    Description
                  </label>
                  <textarea
                    className="form-control"
                    id="edit-description"
                    name="description"
                    value={note.description}
                    onChange={onChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="edit-tag" className="form-label">
                    Tag
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="edit-tag"
                    name="tag"
                    value={note.tag}
                    onChange={onChange}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-ghost" onClick={closeModal}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={!canSave}>
                  <i className="fa-solid fa-floppy-disk" aria-hidden="true"></i>
                  Update Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Notes;
